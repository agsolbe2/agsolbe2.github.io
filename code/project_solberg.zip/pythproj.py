#Document name: pythproj
#Description: Batch Processing with script
#Author: Alec Solberg

# Import system module
import arcpy

database = arcpy.GetParameterAsText(0)
nameofGDB = arcpy.GetParameterAsText(1)
outputcoordinate = arcpy.GetParameterAsText(2)
featureclipper = arcpy.GetParameterAsText(3)
#Setup Workspace
arcpy.env.workspace = database

GDB = arcpy.CreateFileGDB_management(database, nameofGDB)

fclist = arcpy.ListFeatureClasses()

output = featureclipper.replace(".shp", "projected.shp")
output1 = arcpy.Project_management(featureclipper, output, outputcoordinate)

for fc in fclist:
    output3 = fc.replace(".shp", "projectedlist.shp")
    output4 = arcpy.Project_management(fc, output3, outputcoordinate)
    output5 = fc.replace(".shp", "final.shp")
    output6 = arcpy.Clip_analysis(output4, output1, output5)
    arcpy.FeatureClassToGeodatabase_conversion (output6, GDB)
